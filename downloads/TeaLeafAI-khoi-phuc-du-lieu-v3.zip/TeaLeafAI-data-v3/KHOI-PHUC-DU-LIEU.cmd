@echo off
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel% equ 0 (
  py -3 training\restore_dataset_v3.py
) else (
  python training\restore_dataset_v3.py
)
pause
